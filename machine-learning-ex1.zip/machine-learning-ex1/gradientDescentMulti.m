function [theta, J_history] = gradientDescentMulti(X, y, theta, alpha, num_iters)
%GRADIENTDESCENTMULTI Performs gradient descent to learn theta
%   theta = GRADIENTDESCENTMULTI(x, y, theta, alpha, num_iters) updates theta by
%   taking num_iters gradient steps with learning rate alpha

% Initialize some useful values
m = length(y); % number of training examples
J_history = zeros(num_iters, 1);

for iter = 1:num_iters

    % ====================== YOUR CODE HERE ======================
    % Instructions: Perform a single gradient step on the parameter vector
    %               theta. 
    %
    % Hint: While debugging, it can be useful to print out the values
    %       of the cost function (computeCostMulti) and gradient here.
    %

 temp=zeros(length(theta),1);
 for jj=1:length(theta) 
  for ii=1:m
      temp(jj)=temp(jj)+(theta(1)*X(ii,1)+theta(2)*X(ii,2)+theta(3)*X(ii,3)-y(ii))*X(ii,jj);
      %temp2=temp2+(theta(1)*X(ii,1)+theta(2)*X(ii,2)-y(ii))*X(ii,2);
   end
  %theta(2)=theta(2)-(alpha/m)*temp2;
 end
 
%  for jj=1:length(theta)
%   theta(jj)=theta(jj)-(alpha/m)*temp(jj);
%  end

theta=theta-(alpha/m)*temp;










    % ============================================================

    % Save the cost J in every iteration    
    J_history(iter) = computeCostMulti(X, y, theta);

end

end

function g = sigmoid(z)
%SIGMOID Compute sigmoid functoon
%   J = SIGMOID(z) computes the sigmoid of z.

g = zeros(size(z));
z=reshape(z,prod(size(z)),1);
for ii =1:length(z) 
g(ii)=1/(1+exp(-z(ii)));
end

end

function [J, grad] = costFunction(theta, X, y)
%COSTFUNCTION Compute cost and gradient for logistic regression
%   J = COSTFUNCTION(theta, X, y) computes the cost of using theta as the
%   parameter for logistic regression and the gradient of the cost
%   w.r.t. to the parameters.

% Initialize some useful values
m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;
grad = zeros(size(theta));

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost of a particular choice of theta.
%               You should set J to the cost.
%               Compute the partial derivatives and set grad to the partial
%               derivatives of the cost w.r.t. each parameter in theta
%%% Computing cost%%%%%%

for ii=1:m
   temp1=theta'*X(ii,:)';
   %h_theta_xi=1/(1+exp(-temp1));
   h_theta_xi=sigmoid(temp1);
   display(h_theta_xi);
   temp2=-y(ii)*log(h_theta_xi)-(1-y(ii))*log(1-h_theta_xi);
   J=J+temp2;
end
J=J/m;

%%% Computing gradient %%%%%%
clear temp1 temp2 
for jj=1:length(theta)
  for ii=1:m
    temp1=theta'*X(ii,:)';
    h_theta_xi=sigmoid(temp1);
    temp2=(h_theta_xi-y(ii))*X(ii,jj);
    grad(jj)=grad(jj)+temp2;
  end
  grad(jj)=grad(jj)/m;
end



%
% Note: grad should have the same dimensions as theta
%








% =============================================================

end
